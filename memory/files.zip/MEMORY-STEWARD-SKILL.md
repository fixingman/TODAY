---
name: memory-steward
description: >
  Maintain, update, and synchronise project memory files (Architecture.md,
  Design.md, Research.md, Changelog.md) for the TODAY app. Use this skill
  whenever a work session ends, a feature ships, a bug reveals a new gotcha,
  a product decision is made, or the conversation is getting long and slow.
  Also use when the user asks about "memory files", "handoff", "fresh
  conversation", "context", "docs stale", "update the docs", or "start a new
  conversation". This skill must run at the END of every work block — not
  optionally, always.
---

# Memory Steward

Keeps TODAY's memory files accurate, current, and lean so every new
conversation starts from truth rather than drift.

---

## When to run (mandatory triggers)

Run this skill automatically — do not wait to be asked — whenever any of
these conditions are met:

| Trigger | Action |
|---|---|
| Feature shipped (any size) | Update relevant memory files, bump version |
| Bug fixed that hit a non-obvious constraint | Add to Research.md §3 |
| Product decision made with reasoning | Record in relevant memory file |
| Version bumped to x.N.0 or N.0.0 | Write session summary, check all files |
| Conversation exceeds ~40 back-and-forth exchanges | Propose handoff |
| User says "fresh start", "new conversation", "getting slow" | Write handoff doc immediately |
| Work block ends (any reason) | Run the end-of-session checklist below |

---

## Step 1 — End-of-session checklist (run every session)

Work through this in order. Do not skip steps.

### 1a. Version check
- Has everything shipped since the last bump been versioned? If not, bump now.
- Does the change qualify as a minor (`x.N.0`)? Apply versioning rules from Architecture.md §13.
- Are `APP_VERSION`, `DEV_HOURS`, `CACHE_VERSION` in sw.js, `CHANGELOG` object, and `Changelog.md` all consistent?

### 1b. Doc freshness check
Use the trigger table below. For each change made this session, ask: *if someone read only the memory files, would they understand why this exists and how it works?*

| Change type | File to update |
|---|---|
| New localStorage key, backup schema, sync flow, data model | `Architecture.md` §1 or §4 |
| New product rule, merge strategy, new-day logic | `Architecture.md` §11 Key Product Rules |
| New UI component, token added/changed, animation rule | `Design.md` relevant section |
| Interaction pattern added, changed, or deliberately removed | `Design.md` §7 Interaction Decisions |
| Bug fix revealing a browser constraint or gotcha | `Research.md` §3 Technical Gotchas |
| New integration researched | `Research.md` §2 |
| Habit algorithm or scoring change | `Research.md` §4 |
| Feature removed (with reasoning) | `Design.md` §7 + note in Research.md |

### 1c. Housekeeping check (after any bug fix or rework)
- Empty CSS rule blocks → delete
- Dead functions (no longer called) → delete
- Orphaned CSS classes (DOM element removed) → delete
- Stale comments (describe changed behaviour) → update or remove

### 1d. Token consistency (after any CSS change)
- Any new hardcoded hex, rgba, opacity, px, or z-index values?
- Do they have matching `:root` tokens?
- Are aliases defined in the backward-compat block?

---

## Step 2 — Memory file update protocol

When updating a memory file:

1. **Search project knowledge first** — `project_knowledge_search` before reading the file directly. Confirm which section needs updating.
2. **Surgical edits only** — never rewrite a whole section to update one fact. Find the specific table row, bullet, or paragraph.
3. **Keep the reasoning** — don't just record *what* changed, record *why* the decision was made. Future Claude needs to know the reasoning, not just the outcome.
4. **Date is implicit** — do not add "as of v1.7.3" or date stamps inline. The changelog tracks when.
5. **Test the edit** — after updating, re-read the section and ask: does this accurately describe what the code actually does right now?

---

## Step 3 — Conversation length check

Count roughly: is this conversation loading slowly or approaching 50+ exchanges?

**If yes → write a handoff document.**

### Handoff document format

```markdown
# TODAY — Session Handoff

## Current version
- APP_VERSION: x.x.x
- DEV_HOURS: Nh
- SW cache: today-vx.x.x

## File locations
- Live output: /mnt/user-data/outputs/index.html
- SW: /mnt/user-data/outputs/sw.js
- Memory: Architecture.md, Design.md, Research.md, Changelog.md, README.md

## What was just built (this session)
[2–4 bullet points — features, fixes, decisions]

## Open items / next steps
[Explicit list — anything discussed but not shipped]

## Key rules to carry forward
[Only rules that were recently updated or are easy to forget]
- Versioning: patch/minor/major semantics (see Architecture.md §13)
- [any session-specific rule additions]

## Known issues / watch areas
[Bugs spotted but not fixed, edge cases noted]

## Memory file status
- Architecture.md: [current / updated this session / needs update]
- Design.md: [current / updated this session / needs update]
- Research.md: [current / updated this session / needs update]
- Changelog.md: [current]
```

After writing the handoff doc:
1. Save it to `/mnt/user-data/outputs/HANDOFF.md`
2. Present it to the user
3. Tell the user: "Start a new conversation and paste this in to continue with full context."

---

## Step 4 — Memory file quality check (run periodically, not every session)

Run this when explicitly asked or when memory files haven't been quality-checked in a while.

### Staleness signals to look for
- A function exists in code that no memory file explains
- A decision was made that no memory file records the reasoning for  
- A gotcha was hit that no memory file warned about
- A product rule in Architecture.md that the code no longer follows
- A section of Design.md that describes a removed feature as current

### How to check
```bash
# Spot-check: find functions/classes in code with no memory file mention
grep -n "function _haptic\|_logSession\|applyNewDayCleanup" index.html | head -5
# Then search project knowledge for each
```

If you find staleness: fix it immediately using Step 2 above. Do not defer.

---

## Principles

**Memory files are the source of truth, not the conversation.**
The conversation is ephemeral. The memory files are permanent. Every decision, gotcha, and rule that matters must live in a memory file, not just in the chat history.

**Update in the moment, not at the end.**
The right time to update Research.md with a browser gotcha is the moment you hit the gotcha — not at the end of the session when context is cold. The trigger table in Step 1b exists for this reason.

**Never let a version bump close without checking docs.**
The version bump is the checkpoint. Before the bump closes, ask: does anything that just shipped need a memory file update?

**Short conversations are better than long ones.**
A well-maintained set of memory files means every new conversation can start lean and fast. The handoff document is not a failure — it is the system working correctly.
